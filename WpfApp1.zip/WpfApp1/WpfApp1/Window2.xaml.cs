﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Data.Entity;
using MessageBox = System.Windows.Forms.MessageBox;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        demka_bd_PR31Entities servise = new demka_bd_PR31Entities();
        public Window2()
        {
            InitializeComponent();
           
            service_grid.ItemsSource = servise.application_table.ToList();
        }
       
        


        private void dataGrid_serch_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
           
        }

        private void updateButton_Click(object sender, RoutedEventArgs e)
        {
        }

      
        
        private void deleteButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //	Получить все выделенные строки из DataGrid
                //	Cast<> - преобразовать каждую строку в определенный тип
                var data = service_grid.SelectedItems.Cast<application_table>().ToList();
                //	Удалить все выделенные данные
                servise.db.application_table.RemoveRange(data);
                //	Сохранить изменения
                servise.db.SaveChanges();
                MessageBox.Show("Данные удалены");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при удалении данных");
            }

        }
    }
}
