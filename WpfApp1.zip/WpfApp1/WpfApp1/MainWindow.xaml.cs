﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_edit_Click(object sender, RoutedEventArgs e)
        {
            var newForm = new Window1(); //create your new form.
            newForm.Show(); //show the new form.
            this.Close();
        }

        private void btn_serch_Click(object sender, RoutedEventArgs e)
        {
            var newForm = new Window2(); //create your new form.
            newForm.Show(); //show the new form.
            this.Close();
        }

        private void btn_add_Click(object sender, RoutedEventArgs e)
        {
            var newForm = new Window3(); //create your new form.
            newForm.Show(); //show the new form.
            this.Close();
        }

        private void btn_fix_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
